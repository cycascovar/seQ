<?php

/*Encrypt this shit*/
$seqapp_encrypt="1z6hn49jdGmgt+";
/*Decrypt this shit*/
$seqapp_decrypt="MXo2aG40OWpkR21ndCs=";



?>