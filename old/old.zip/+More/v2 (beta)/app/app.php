<?


$string= $_POST['string'];
$enc_dec = $_POST['enc_dec'];

echo $string;
echo $enc_dec;


?>